
// This service has been completely removed per client request
export async function getCheckoutCustomization() {
  return null;
}

export async function saveCheckoutCustomization() {
  return null;
}

export async function getPaymentInfo() {
  return null;
}

export async function savePaymentInfo() {
  return null;
}
