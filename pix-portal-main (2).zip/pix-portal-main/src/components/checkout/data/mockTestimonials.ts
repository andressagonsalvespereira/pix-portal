
export const mockTestimonials = [
  {
    id: '1',
    author: 'Ricardo dos Reis',
    content: 'Ótima escolha! Qualidade do produto, satisfação garantida.',
    rating: 5,
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
    date: '2 dias atrás'
  },
  {
    id: '2',
    author: 'Juliana Vasconcelos',
    content: 'Produto surpreendente! Eu recomendo a qualquer um.',
    rating: 5,
    avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
    date: '5 dias atrás'
  },
  {
    id: '3',
    author: 'Rafaela Gomes',
    content: 'Achei simples, satisfatório, cumpre bem o objetivo.',
    rating: 4,
    avatar: 'https://randomuser.me/api/portraits/women/68.jpg',
    date: '1 semana atrás'
  }
];
