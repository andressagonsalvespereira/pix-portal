
export const steps = [
  {
    title: "Informações pessoais",
    description: "Preencha seus dados"
  },
  {
    title: "Método de pagamento",
    description: "Escolha como deseja pagar"
  },
  {
    title: "Confirmar pagamento",
    description: "Revisar e finalizar compra"
  }
];
